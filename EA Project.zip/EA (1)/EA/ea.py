import pandas as pd
import numpy as np
import random
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Tuple
from collections import defaultdict
import time
import warnings
from enum import Enum, auto
from scipy.spatial.distance import cdist
import os
import sys
import io
# Suppress FutureWarnings from pandas
warnings.filterwarnings("ignore", category=FutureWarning)

base_dir = os.path.dirname(os.path.abspath(__file__))


class SelectionMethod(Enum):
    TOURNAMENT = auto()
    ROULETTE = auto()
    EXPONENTIAL_RANK = auto()

class InitializationMethod(Enum):
    RANDOM = auto()    
    HEURISTIC = auto()   
    SIZE_BASED = auto()  
    
class CrossoverMethod(Enum):
    UNIFORM = auto()
    SINGLE_POINT = auto()
    TWO_POINT = auto()


class MutationMethod(Enum):
    TIME_SLOT = auto()
    ROOM_ASSIGNMENT = auto()
    SPLIT_ROOMS = auto()
    DAY_CHANGE = auto()


class SurvivorSelection(Enum):
    GENERATIONAL = auto()
    STEADY_STATE = auto()
    ELITISM = auto()


class DiversityMethod(Enum):
    FITNESS_SHARING = auto()
    CROWDING = auto()
    HYBRID = auto()

class BasicParameterTuner:
    def __init__(self, scheduler,config=None):
        self.config = config or {}
        self.scheduler = scheduler
        self.parameter_space = {
            'POPULATION_SIZE': [50, 100, 150],
            'GENERATIONS': [50, 100, 150],
            'MUTATION_RATE': [0.1, 0.3, 0.5],
            'CROSSOVER_RATE': [0.7, 0.85, 0.95],
            'ELITISM_RATE': [0.05, 0.1, 0.2],
            'selection_method': [self.config.get("parent_selection")],
            'mutation_methods': [self.config.get("mutation_type")]
            
        }
        self.tuning_results = []

    def simple_tune(self, num_configs=5, num_runs=2):
        """Simplified parameter tuning with random sampling"""
        import random
        from itertools import product

        # Generate all possible combinations
        param_names = list(self.parameter_space.keys())
        all_combinations = list(product(*[self.parameter_space[name] for name in param_names]))

        # Randomly select configurations to test
        selected_combinations = random.sample(all_combinations, min(num_configs, len(all_combinations)))

        print(f"Testing {len(selected_combinations)} configurations")

        for i, combination in enumerate(selected_combinations):
            params = dict(zip(param_names, combination))

            print(f"\nConfiguration {i + 1}/{len(selected_combinations)}")
            print("Parameters:")
            for k, v in params.items():
                print(f"  {k}: {v}")

            # Set parameters
            for param, value in params.items():
                setattr(self.scheduler, param, value)

            # Run multiple times
            run_fitness = []
            for _ in range(num_runs):
                try:
                    # Reset scheduler state
                    self.scheduler.best_fitness = float('inf')
                    self.scheduler.best_timetable = None
                    self.scheduler.fitness_history = []

                    # Create initial population
                    population = []
                    for _ in range(self.scheduler.POPULATION_SIZE):
                        ind = self.scheduler.create_individual()
                        if ind:
                            population.append(ind)

                    if not population:
                        run_fitness.append(float('inf'))
                        continue

                    # Evaluate initial population
                    with ThreadPoolExecutor(max_workers=self.scheduler.NUM_THREADS) as executor:
                        fitness_scores = [result[2] for result in
                                          executor.map(self.scheduler.hybrid_fitness, population)]

                    best_fitness = min(fitness_scores)
                    run_fitness.append(best_fitness)

                except Exception as e:
                    print(f"Error during evaluation: {str(e)}")
                    run_fitness.append(float('inf'))

            # Record results
            avg_fitness = np.mean(run_fitness)
            std_fitness = np.std(run_fitness)
            min_fitness = min(run_fitness)
            max_fitness = max(run_fitness)

            self.tuning_results.append({
                'params': params,
                'avg_fitness': avg_fitness,
                'std_fitness': std_fitness,
                'min_fitness': min_fitness,
                'max_fitness': max_fitness,
                'runs': run_fitness
            })

            print(
                f"Results - Avg: {avg_fitness:.1f}, Std: {std_fitness:.1f}, Min: {min_fitness:.1f}, Max: {max_fitness:.1f}")

        return self.tuning_results

    def get_best_parameters(self):
        """Return the best performing parameter set"""
        if not self.tuning_results:
            return None, float('inf')

        best_result = min(self.tuning_results, key=lambda x: x['avg_fitness'])
        return best_result['params'], best_result['avg_fitness']

    def print_results(self):
        """Print all tuning results"""
        if not self.tuning_results:
            print("No tuning results available")
            return

        print("\nParameter Tuning Results:")
        print("=" * 80)

        # Sort by average fitness
        sorted_results = sorted(self.tuning_results, key=lambda x: x['avg_fitness'])

        for i, result in enumerate(sorted_results):
            print(f"\nRank {i + 1} (Avg Fitness: {result['avg_fitness']:.1f} ± {result['std_fitness']:.1f})")
            print("-" * 60)
            for param, value in result['params'].items():
                print(f"{param:20}: {value}")
            print(f"\nRuns: {result['runs']}")

class FinalExamScheduler:
    def __init__(self,config=None):
        self.config = config or {}
        # Constants with adjustable parameters
        self.schedule_df = None
        self.classrooms_df = None
        self.timeslots_df = None
        self.courses_df = None
        self.students_df = None
        self.initialization_method = self.config.get("initialization_method")
        self.heuristic_init_ratio = 0.3
        self.HARD_SUBJECTS = ['Healthcare Informatics', 'Mechanical Engineering']
        self.MAX_EXAMS_PER_DAY = 5
        self.MIN_EXAM_DAYS = 7
        self.ELITISM_RATE = 0.1
        self.MAX_STAGNATION = 50
        self.POPULATION_SIZE = self.config.get("population_size", 100)
        self.GENERATIONS = self.config.get("generations", 500)
        self.NUM_THREADS = 4

        self.conflict_details = []
        self.MUTATION_RATE = self.config.get("mutation_rate", .3)
        self.CROSSOVER_RATE = self.config.get("crossover_rate", .9)
        self.MISSING_COURSE_PENALTY = 10000
        self.STUDENT_DOUBLE_BOOKING_PENALTY = 2000
        self.ROOM_OVER_CAPACITY_PENALTY = 1000
        self.ROOM_DOUBLE_BOOKING_PENALTY = 1500
        self.STUDENT_LOAD_PENALTY = 100
        self.DAY_DISTRIBUTION_PENALTY = 200
        self.UNUSED_ROOMS_PENALTY = 50
        self.ROOM_IMBALANCE_PENALTY = 100
        self.HARD_SUBJECT_CONFLICT_PENALTY = 600

        # Diversity parameters
        self.SHARING_RADIUS = 0.5  # For fitness sharing
        self.ALPHA = 1.0  # Scaling factor for fitness sharing
        self.CROWDING_FACTOR = 2  # For crowding replacement

        # Algorithm configuration
        self.selection_method = self.config.get("parent_selection")
        self.crossover_method = self.config.get("crossover_type")
        self.mutation_methods = self.config.get("mutation_type")
        self.survivor_selection_method = self.config.get("survivor_selection")
        self.diversity_method = DiversityMethod.HYBRID  # Now using Enum

        # Data structures
        self.student_courses = None
        self.course_students = None
        self.timeslot_to_day = None
        self.course_names = None
        self.room_capacities = None
        self.course_difficulty = None
        self.days = None
        self.day_to_timeslots = None

        # Tracking
        self.best_fitness = -float('inf')
        self.best_timetable = None
        self.fitness_history = []
        self.diversity_history = []
        self.run_stats = []
        self.current_run_seed = None
        self.penalty_details = []
        self.conflict_details = []

        # Load and prepare data
        self.load_data()
        self.prepare_data_structures()

    def calculate_conflicts(self, timetable):
        """Calculate and return student and room conflicts"""
        student_conflicts = defaultdict(list)
        room_conflicts = defaultdict(list)

        # Track all exams by time and room
        time_room_exams = defaultdict(lambda: defaultdict(list))

        for course, (time, room_assignments) in timetable.items():
            for room, students in room_assignments:
                time_room_exams[time][room].append(course)

                # Track student schedules
                for student in students:
                    if student not in student_conflicts:
                        student_conflicts[student] = []
                    student_conflicts[student].append((time, course))

        # Find room conflicts (multiple courses in same room at same time)
        for time, rooms in time_room_exams.items():
            for room, courses in rooms.items():
                if len(courses) > 1:
                    room_conflicts[room].append({
                        'time': time,
                        'day': self.timeslot_to_day.get(time, 'Unknown'),
                        'courses': courses,
                        'course_names': [self.course_names.get(c, 'Unknown') for c in courses]
                    })

        # Find student conflicts (multiple exams at same time)
        conflicting_students = defaultdict(list)
        for student, exams in student_conflicts.items():
            time_counts = defaultdict(list)
            for time, course in exams:
                time_counts[time].append(course)

            for time, courses in time_counts.items():
                if len(courses) > 1:
                    conflicting_students[student].append({
                        'time': time,
                        'day': self.timeslot_to_day.get(time, 'Unknown'),
                        'courses': courses,
                        'course_names': [self.course_names.get(c, 'Unknown') for c in courses]
                    })

        return dict(conflicting_students), dict(room_conflicts)

    def print_student_conflicts(self, student_conflicts):
        """Print students with conflicting exams"""
        if not student_conflicts:
            print("\nNo students with conflicting exams found")
            return

        print("\n" + "=" * 50)
        print("STUDENTS WITH CONFLICTING EXAMS")
        print("=" * 50)
        print(f"Total students with conflicts: {len(student_conflicts)}")

        for student_id, conflicts in student_conflicts.items():
            print(f"\nStudent ID: {student_id}")
            for conflict in conflicts:
                print(f"  Time {conflict['time']} (Day {conflict['day']}):")
                for course_name in conflict['course_names']:
                    print(f"    - {course_name}")

    def print_room_conflicts(self, room_conflicts):
        """Print rooms with conflicting exams"""
        if not room_conflicts:
            print("\nNo rooms with conflicting exams found")
            return

        print("\n" + "=" * 50)
        print("ROOMS WITH CONFLICTING EXAMS")
        print("=" * 50)
        print(f"Total rooms with conflicts: {len(room_conflicts)}")

        for room_id, conflicts in room_conflicts.items():
            print(f"\nRoom ID: {room_id} (Capacity: {self.room_capacities.get(room_id, 'Unknown')})")
            for conflict in conflicts:
                print(f"  Time {conflict['time']} (Day {conflict['day']}):")
                for course_name in conflict['course_names']:
                    print(f"    - {course_name}")

    def print_conflict_statistics(self, timetable):
        """Print detailed conflict statistics"""
        student_conflicts, room_conflicts = self.calculate_conflicts(timetable)

        self.print_student_conflicts(student_conflicts)
        self.print_room_conflicts(room_conflicts)

        return len(student_conflicts), len(room_conflicts)

    def check_constraint_violations(self, timetable, verbose=False):
        

        raw_violations = {
            'missing_courses': 0,
            'room_over_capacity': 0,
            'room_double_booking': 0,
            'student_double_booking': 0,
            'hard_subject_spacing': 0,
            'unused_rooms': 0,
            'too_many_exams_per_day': 0,
            'too_few_exam_days': 0
        }

        # Store detailed descriptions of each violation
        violation_details = defaultdict(list)

        # Trackers
        student_schedule = defaultdict(list)
        student_exams = defaultdict(list)
        room_time_course = defaultdict(list)
        day_courses = defaultdict(list)
        used_rooms = set()

        # 1. Missing courses
        missing = set(self.courses) - set(timetable.keys())
        raw_violations['missing_courses'] = len(missing)
        for course in missing:
            violation_details['missing_courses'].append(f"Course {course} not scheduled.")

        for course, (time, room_assignments) in timetable.items():
            day = self.timeslot_to_day.get(time, 'Unknown')
            students = list(self.course_student_sets.get(course, set()))
            day_courses[day].append(course)

            for room, assigned_students in room_assignments:
                used_rooms.add(room)
                capacity = self.room_capacities.get(room, 0)

                # 2. Room over capacity
                if len(assigned_students) > capacity:
                    raw_violations['room_over_capacity'] += 1
                    violation_details['room_over_capacity'].append(
                        f"Room {room} over capacity in course {course} (assigned {len(assigned_students)}, capacity {capacity})."
                    )

                # 3. Room double booking
                for t, c in room_time_course[room]:
                    if t == time:
                        raw_violations['room_double_booking'] += 1
                        violation_details['room_double_booking'].append(
                            f"Room {room} double-booked at time {time} for courses {c} and {course}."
                        )
                        break
                room_time_course[room].append((time, course))

                # Track students
                for student in assigned_students:
                    student_schedule[student].append(time)
                    student_exams[student].append((time, course))

        # 4. Student double booking
        for student, times in student_schedule.items():
            if len(times) != len(set(times)):
                raw_violations['student_double_booking'] += 1
                violation_details['student_double_booking'].append(
                    f"Student {student} has multiple exams at the same time: {times}"
                )

        # 5. Hard subject spacing
        for student, exams in student_exams.items():
            sorted_exams = sorted(exams)
            for i in range(1, len(sorted_exams)):
                t1, c1 = sorted_exams[i - 1]
                t2, c2 = sorted_exams[i]
                if self.is_hard_subject(c1) and self.is_hard_subject(c2):
                    if t2 - t1 < 2 or self.timeslot_to_day.get(t1) == self.timeslot_to_day.get(t2):
                        raw_violations['hard_subject_spacing'] += 1
                        violation_details['hard_subject_spacing'].append(
                            f"Student {student} has hard subjects {c1} and {c2} too close at times {t1} and {t2}."
                        )
                        break

        # 6. Too many exams per day
        for day, exams in day_courses.items():
            if len(exams) > self.MAX_EXAMS_PER_DAY:
                raw_violations['too_many_exams_per_day'] += 1
                violation_details['too_many_exams_per_day'].append(
                    f"{len(exams)} exams scheduled on day {day}, exceeding limit {self.MAX_EXAMS_PER_DAY}."
                )

        # 7. Too few exam days
        if len(day_courses) < self.MIN_EXAM_DAYS:
            raw_violations['too_few_exam_days'] = self.MIN_EXAM_DAYS - len(day_courses)
            violation_details['too_few_exam_days'].append(
                f"Only {len(day_courses)} exam days used; minimum required is {self.MIN_EXAM_DAYS}."
            )

        # 8. Unused rooms
        unused = set(self.rooms) - used_rooms
        raw_violations['unused_rooms'] = len(unused)
        for room in unused:
            violation_details['unused_rooms'].append(f"Room {room} was not used at all.")

        # Penalty multipliers
        penalty_multipliers = {
            'missing_courses': self.MISSING_COURSE_PENALTY,
            'room_over_capacity': self.ROOM_OVER_CAPACITY_PENALTY,
            'room_double_booking': self.ROOM_DOUBLE_BOOKING_PENALTY,
            'student_double_booking': self.STUDENT_DOUBLE_BOOKING_PENALTY,
            'hard_subject_spacing': self.HARD_SUBJECT_CONFLICT_PENALTY,
            'unused_rooms': self.UNUSED_ROOMS_PENALTY,
            'too_many_exams_per_day': self.DAY_DISTRIBUTION_PENALTY,
            'too_few_exam_days': self.DAY_DISTRIBUTION_PENALTY
        }

        # Compute penalties
        penalties = {
            k: raw_violations[k] * penalty_multipliers[k]
            for k in raw_violations
        }

        total_penalty = sum(penalties.values())

        if verbose:
            print("\n===== Constraint Violations Breakdown =====")
            for k in raw_violations:
                print(f"{k}: {raw_violations[k]} violations x {penalty_multipliers[k]} = {penalties[k]}")
                for detail in violation_details[k]:
                    print(f"    - {detail}")
            print("===========================================")
            print(f"Total Penalty: {total_penalty}\n")

        return raw_violations, penalties, total_penalty, violation_details


    def hybrid_fitness(self, timetable):
        raw_violations, penalties, total_penalty, violation_details = self.check_constraint_violations(timetable, verbose=False)
        return raw_violations, penalties, total_penalty, violation_details

    def is_hard_subject(self, course_id):
        course_name = self.course_names.get(course_id, "")
        return any(subj in course_name for subj in self.HARD_SUBJECTS)

    def print_conflict_details(self):
        """Print detailed information about conflicts"""
        if not self.conflict_details or not self.best_timetable:
            print("No conflict details available")
            return

        # Get details for best solution
        best_idx = min(range(len(self.penalty_details)),
                       key=lambda i: self.penalty_details[i]['total_penalty'])
        conflicts = self.conflict_details[best_idx]

        print("\n" + "=" * 50)
        print("DETAILED CONFLICT ANALYSIS")
        print("=" * 50)

        # Missing courses
        if conflicts['missing_courses']:
            print(f"\nMissing Courses ({len(conflicts['missing_courses'])}):")
            for course in conflicts['missing_courses']:
                print(f"- {self.course_names.get(course, 'Unknown')} ({course})")

        # Unused rooms
        if conflicts['unused_rooms']:
            print(f"\nUnused Rooms ({len(conflicts['unused_rooms'])}):")
            for room in conflicts['unused_rooms']:
                print(f"- {room} (Capacity: {self.room_capacities.get(room, 0)})")

        # Student conflicts
        if conflicts['student_conflicts']:
            print(f"\nStudents with Conflicts ({len(conflicts['student_conflicts'])}):")
            for student, conflicts_list in conflicts['student_conflicts'].items():
                print(f"\nStudent {student}:")
                for conflict in conflicts_list:
                    print(f"  Time {conflict['time']} (Day {conflict['day']}):")
                    for name in conflict['course_names']:
                        print(f"    - {name}")

        # Room conflicts
        if conflicts['room_conflicts']:
            print(f"\nRoom Conflicts ({len(conflicts['room_conflicts'])}):")
            for room, messages in conflicts['room_conflicts'].items():
                print(f"\nRoom {room} (Capacity: {self.room_capacities.get(room, 0)}):")
                for msg in messages:
                    print(f"  - {msg}")

        # Hard subject violations
        if conflicts['hard_subject_violations']:
            print(f"\nHard Subject Violations ({len(conflicts['hard_subject_violations'])}):")
            for student, messages in conflicts['hard_subject_violations'].items():
                print(f"\nStudent {student}:")
                for msg in messages:
                    print(f"  - {msg}")

    def print_penalty_analysis(self):
        """Print detailed analysis of penalties for the best solution"""
        if not self.penalty_details:
            print("No penalty analysis available")
            return

        best_details = min(self.penalty_details, key=lambda x: x['total_penalty'])

        print("\n" + "=" * 50)
        print("PENALTY BREAKDOWN ANALYSIS")
        print("=" * 50)

        print(f"\n{'Metric':<40} {'Count':>15} {'Penalty':>15}")
        print("-" * 70)
        print(
            f"{'Missing courses':<40} {len(self.courses) - len(self.best_timetable):>15} {best_details['hard_penalties']:>15,.2f}")
        print(
            f"{'Student double bookings':<40} {len(self.conflict_details[-1]['student_conflicts']):>15} {best_details['hard_penalties']:>15,.2f}")
        print(f"{'Room capacity violations':<40} {'-':>15} {best_details['hard_penalties']:>15,.2f}")
        print(
            f"{'Room double bookings':<40} {len(self.conflict_details[-1]['room_conflicts']):>15} {best_details['hard_penalties']:>15,.2f}")
        print(
            f"{'Hard subject conflicts':<40} {len(self.conflict_details[-1]['hard_subject_violations']):>15} {best_details['soft_penalties']:>15,.2f}")
        print(f"{'Student exam load issues':<40} {'-':>15} {best_details['soft_penalties']:>15,.2f}")
        print(f"{'Day distribution issues':<40} {'-':>15} {best_details['soft_penalties']:>15,.2f}")
        print(
            f"{'Unused rooms':<40} {len(self.conflict_details[-1]['unused_rooms']):>15} {best_details['soft_penalties']:>15,.2f}")
        print(f"{'Room imbalance':<40} {'-':>15} {best_details['soft_penalties']:>15,.2f}")
        print("-" * 70)
        print(f"{'TOTAL HARD PENALTIES':<40} {'-':>15} {best_details['hard_penalties']:>15,.2f}")
        print(f"{'TOTAL SOFT PENALTIES':<40} {'-':>15} {best_details['soft_penalties']:>15,.2f}")
        print(f"{'TOTAL PENALTY':<40} {'-':>15} {best_details['total_penalty']:>15,.2f}")

    def load_data(self):
        try:
            # Construct full file paths
            schedule_path = os.path.join(base_dir, "schedule.csv")
            classrooms_path = os.path.join(base_dir, "classrooms.csv")
            timeslots_path = os.path.join(base_dir, "timeslots.csv")
            courses_path = os.path.join(base_dir, "courses.csv")
            students_path = os.path.join(base_dir, "students.csv")

            # Load CSV files with dtypes
            self.schedule_df = pd.read_csv(schedule_path, dtype={
                'student_id': 'category',
                'course_id': 'category',
                'timeslot_id': 'int16',
                'classroom_id': 'category'
            })

            self.classrooms_df = pd.read_csv(classrooms_path, dtype={
                'classroom_id': 'category',
                'capacity': 'int16'
            })

            self.timeslots_df = pd.read_csv(timeslots_path, dtype={
                'timeslot_id': 'int16',
                'day': 'category'
            })

            self.courses_df = pd.read_csv(courses_path, dtype={
                'course_id': 'category',
                'course_name': 'str'
            })

            self.students_df = pd.read_csv(students_path)  # Adjust dtype if needed

            # Validate required columns
            required_columns = {
                'schedule_df': ['student_id', 'course_id', 'timeslot_id', 'classroom_id'],
                'classrooms_df': ['classroom_id', 'capacity'],
                'timeslots_df': ['timeslot_id', 'day'],
                'courses_df': ['course_id', 'course_name'],
                'students_df': ['student_id']  # Adjust if other columns required
            }

            for df_attr, cols in required_columns.items():
                df = getattr(self, df_attr)
                if not set(cols).issubset(df.columns):
                    raise ValueError(f"Missing required columns in {df_attr.replace('_df','')}.csv")

        except Exception as e:
            print(f"Error loading data: {str(e)}")
            raise

    def prepare_data_structures(self):
        """Prepare optimized data structures for scheduling."""
        try:
            # Merge schedule with timeslots
            self.schedule_df = pd.merge(
                self.schedule_df,
                self.timeslots_df,
                on='timeslot_id',
                how='left',
                validate='many_to_one'
            )

            # Create student-course mappings
            self.student_courses = self.schedule_df.groupby('student_id', observed=True)['course_id'].agg(
                list).to_dict()
            self.course_students = self.schedule_df.groupby('course_id', observed=True)['student_id'].agg(
                list).to_dict()

            # Convert to sets for faster operations
            self.course_student_sets = {
                course: set(students)
                for course, students in self.course_students.items()
            }

            # Create lookup dictionaries
            self.timeslot_to_day = self.timeslots_df.set_index('timeslot_id')['day'].to_dict()
            self.course_names = self.courses_df.set_index('course_id')['course_name'].to_dict()
            self.room_capacities = self.classrooms_df.set_index('classroom_id')['capacity'].to_dict()

            # Calculate course difficulties
            self.course_difficulty = {
                course_id: 2 if any(subj in str(name) for subj in self.HARD_SUBJECTS) else 1
                for course_id, name in self.course_names.items()
            }

            # Get unique values
            self.courses = set(self.courses_df['course_id'].unique())
            self.rooms = set(self.classrooms_df['classroom_id'].unique())
            self.timeslots = self.timeslots_df['timeslot_id'].unique()
            self.days = set(self.timeslots_df['day'].unique())

            # Create day to timeslots mapping
            self.day_to_timeslots = defaultdict(list)
            for ts, day in self.timeslot_to_day.items():
                self.day_to_timeslots[day].append(ts)

            # Ensure MIN_EXAM_DAYS doesn't exceed available days
            self.MIN_EXAM_DAYS = min(self.MIN_EXAM_DAYS, len(self.days))

            if not self.courses:
                raise ValueError("No courses found")
            if not self.rooms:
                raise ValueError("No rooms found")
            if len(self.timeslots) == 0:
                raise ValueError("No timeslots found")

        except Exception as e:
            print(f"Error preparing data structures: {str(e)}")
            raise

    def schedule_course(self, course, timetable, student_time_map, room_time_map):
        students = list(self.course_student_sets.get(course, set()))
        if not students:
            return random.choice(list(self.timeslot_to_day.keys())), []

        # Find times that do not conflict for students
        conflict_times = set()
        for student in students:
            conflict_times |= student_time_map[student]
        available_times = [t for t in self.timeslot_to_day if t not in conflict_times]
        if not available_times:
            available_times = list(self.timeslot_to_day.keys())

        time = random.choice(available_times)

        # Assign rooms without double-booking at that time
        available_rooms = [r for r in self.rooms if time not in room_time_map[r]]
        if not available_rooms:
            available_rooms = list(self.rooms)

        room_assignments = []
        remaining_students = students.copy()

        while remaining_students and available_rooms:
            room = max(available_rooms, key=lambda r: self.room_capacities[r])
            capacity = self.room_capacities[room]
            assigned = remaining_students[:capacity]
            remaining_students = remaining_students[capacity:]

            room_assignments.append((room, assigned))
            available_rooms.remove(room)
            room_time_map[room].add(time)

            # Update student map
            for s in assigned:
                student_time_map[s].add(time)

        return time, room_assignments
    def repair_student_conflicts(self, individual: Dict) -> Dict:
        """Ensure no student has more than one exam in the same timeslot."""
        student_times = defaultdict(set)

        for course, (timeslot, rooms) in individual.items():
            for _, students in rooms:
                for student in students:
                    if timeslot in student_times[student]:
                        # Conflict detected — move course to a different time
                        available = [ts for ts in self.timeslots if ts not in student_times[student]]
                        if available:
                            new_ts = random.choice(available)
                            individual[course] = (new_ts, rooms)
                            timeslot = new_ts  # update timeslot variable
                            break
                    student_times[student].add(timeslot)
        return individual
    def create_random_individual(self):
        """إنشاء جدول عشوائي بدون أي إرشادات"""
        timetable = {}
        for course in self.courses:
            timetable[course] = self.schedule_course(course, timetable)
        return timetable
    
    def create_heuristic_individual(self):
       
        timetable = {}
        
        sorted_courses = sorted(self.courses,
                              key=lambda c: self.course_difficulty.get(c, 1),
                              reverse=True)
        
        
        for course in sorted_courses:
            if self.course_difficulty.get(course, 1) > 1:
                
                time = self.find_isolated_timeslot(timetable)
            else:
                time = random.choice(list(self.timeslot_to_day.keys()))
            
            
            rooms = self.assign_rooms(course, time)
            timetable[course] = (time, rooms)
        
        return timetable

    def create_size_based_individual(self):
          
          timetable = {}
          
          sorted_courses = sorted(self.courses,
                                key=lambda c: len(self.course_student_sets.get(c, set())),
                                reverse=True)
          
          
          for course in sorted_courses:
              students = self.course_student_sets.get(course, set())
              
              time = self.find_least_used_time(students, timetable)
              rooms = self.assign_rooms(course, time)
              timetable[course] = (time, rooms)
          
          return timetable  
    def find_isolated_timeslot(self, timetable):
        
        used_times = {t for c, (t, _) in timetable.items() 
                    if self.course_difficulty.get(c, 1) > 1}
        available = [t for t in self.timeslot_to_day if t not in used_times]
        return random.choice(available) if available else random.choice(list(self.timeslot_to_day.keys()))

    def find_least_used_time(self, students, timetable):
        
        time_counts = defaultdict(int)
        for s in students:
            for c, (t, _) in timetable.items():
                if s in self.course_student_sets.get(c, set()):
                    time_counts[t] += 1
        return min(self.timeslot_to_day.keys(), key=lambda t: time_counts.get(t, 0))

    def assign_rooms(self, course, time):
        
        students = list(self.course_student_sets.get(course, set()))
        rooms = []
        while students:
            room = self.find_best_room(time)
            capacity = self.room_capacities[room]
            rooms.append((room, students[:capacity]))
            students = students[capacity:]
        return rooms    
        
              
    def create_individual(self):
          timetable = {}
          student_time_map = defaultdict(set)  # student_id -> set of time slots
          room_time_map = defaultdict(set)     # room_id -> set of time slots

          for course in self.courses:
              time, room_assignments = self.schedule_course(course, timetable, student_time_map, room_time_map)
              timetable[course] = (time, room_assignments)
          timetable = self.repair_student_conflicts(timetable)

          return timetable
      

    def tournament_selection(self, population: List[Dict], fitness_scores: List[float], k: int = 7) -> Dict:
        """Tournament selection with size k."""
        candidates = random.sample(range(len(population)), k)
        best_index = min(candidates, key=lambda i: fitness_scores[i])
        return population[best_index]

    def roulette_wheel_selection(self, population: List[Dict], fitness_scores: List[float]) -> Dict:
        """Roulette wheel (fitness proportional) selection."""
        # Convert fitness scores to positive values for selection
        max_fitness = max(fitness_scores)
        adjusted_fitness = [max_fitness - f + 1 for f in fitness_scores]
        total_fitness = sum(adjusted_fitness)

        if total_fitness <= 0:
            return random.choice(population)

        pick = random.uniform(0, total_fitness)
        current = 0
        for i, fitness in enumerate(adjusted_fitness):
            current += fitness
            if current > pick:
                return population[i]
        return population[-1]

    def exponential_rank_selection(self, population: List[Dict], fitness_scores: List[float],
                                   lambda_: float = 0.01) -> Dict:
        # lambda_ = 4 / len(population)  

        """Exponential ranking selection"""
        
        ranked_indices = np.argsort(fitness_scores)
        ranks = np.arange(len(population))  

        
        exp_weights = np.exp(-lambda_ * ranks)
        probabilities = exp_weights / np.sum(exp_weights)

        
        selected_idx = np.random.choice(ranked_indices, p=probabilities)
        return population[selected_idx]

    def uniform_crossover(self, parent1: Dict, parent2: Dict) -> Tuple[Dict, Dict]:
        """Uniform crossover between two parents with conflict handling."""
        child1, child2 = {}, {}
        all_courses = set(parent1.keys()).union(set(parent2.keys()))

        for course in all_courses:
            if random.random() < 0.5:
                source1, source2 = parent1, parent2
            else:
                source1, source2 = parent2, parent1

            if course in source1:
                child1[course] = source1[course]
            if course in source2:
                child2[course] = source2[course]

        # Fix student double-booking
        child1 = self.repair_student_conflicts(child1)
        child2 = self.repair_student_conflicts(child2)
        return child1, child2


    def two_point_crossover(self, parent1: Dict, parent2: Dict) -> Tuple[Dict, Dict]:
      """Two-point crossover between two parents with conflict handling."""
      courses1 = list(parent1.keys())
      courses2 = list(parent2.keys())

      if not courses1 or not courses2:
          return parent1.copy(), parent2.copy()

      common_courses = list(set(courses1) & set(courses2))
      if not common_courses:
          return self.uniform_crossover(parent1, parent2)

      common_courses_sorted = sorted(common_courses)
      length = len(common_courses_sorted)

      if length < 3:
          return self.uniform_crossover(parent1, parent2)

      point1 = random.randint(1, length - 2)
      point2 = random.randint(point1 + 1, length - 1)

      child1, child2 = {}, {}

      for i, course in enumerate(common_courses_sorted):
          if i < point1 or i >= point2:
              if course in parent1:
                  child1[course] = parent1[course]
          else:
              if course in parent2:
                  child1[course] = parent2[course]

      for i, course in enumerate(common_courses_sorted):
          if i < point1 or i >= point2:
              if course in parent2:
                  child2[course] = parent2[course]
          else:
              if course in parent1:
                  child2[course] = parent1[course]

      child1 = self.repair_student_conflicts(child1)
      child2 = self.repair_student_conflicts(child2)

      return child1, child2
    def single_point_crossover(self, parent1: Dict, parent2: Dict) -> Tuple[Dict, Dict]:
        """Single-point crossover between two parents."""
        courses1 = list(parent1.keys())
        courses2 = list(parent2.keys())

        if not courses1 or not courses2:
            return parent1.copy(), parent2.copy()

        # Find common courses for meaningful crossover
        common_courses = list(set(courses1) & set(courses2))
        if not common_courses:
            return self.uniform_crossover(parent1, parent2)

        # Sort courses to maintain structure
        common_courses_sorted = sorted(common_courses)
        length = len(common_courses_sorted)

        if length < 2:
            return self.uniform_crossover(parent1, parent2)

        point = random.randint(1, length - 1)

        child1, child2 = {}, {}

        for i, course in enumerate(common_courses_sorted):
            if i < point:
                if course in parent1:
                    child1[course] = parent1[course]
                if course in parent2:
                    child2[course] = parent2[course]
            else:
                if course in parent2:
                    child1[course] = parent2[course]
                if course in parent1:
                    child2[course] = parent1[course]

        return child1, child2


    def timeslot_mutation(self, individual: Dict) -> Dict:
        """Change time within same day"""
        if not individual:
            return individual

        course = random.choice(list(individual.keys()))
        current_time = individual[course][0]
        current_day = self.timeslot_to_day[current_time]
        available_times = [ts for ts, day in self.timeslot_to_day.items() if day == current_day]

        if available_times:
            new_time = random.choice(available_times)
            individual[course] = (new_time, individual[course][1])

        return individual

    def room_assignment_mutation(self, individual: Dict) -> Dict:
        """Change room assignments with conflict-aware logic."""
        if not individual:
            return individual

        course = random.choice(list(individual.keys()))
        time, _ = individual[course]

        # Get students assigned at this timeslot to other courses
        timeslot_students = set()
        for c, (ts, rooms) in individual.items():
            if c != course and ts == time:
                for _, students in rooms:
                    timeslot_students.update(students)

        # Shuffle students of this course
        all_students = self.course_students[course]
        random.shuffle(all_students)

        # Avoid assigning students that already have an exam in the same timeslot
        available_students = [s for s in all_students if s not in timeslot_students]

        new_assignments = []
        remaining_students = available_students.copy()
        available_rooms = list(self.rooms)

        while remaining_students and available_rooms:
            room = random.choice(available_rooms)
            capacity = self.room_capacities[room]
            room_students = remaining_students[:capacity]
            remaining_students = remaining_students[capacity:]
            new_assignments.append((room, room_students))
            available_rooms.remove(room)

        individual[course] = (time, new_assignments)
        return individual


    def day_change_mutation(self, individual: Dict) -> Dict:
        """Change to a different day"""
        if not individual:
            return individual

        course = random.choice(list(individual.keys()))
        current_time = individual[course][0]
        current_day = self.timeslot_to_day[current_time]
        available_days = [d for d in self.days if d != current_day]

        if available_days:
            new_day = random.choice(available_days)
            available_times = [ts for ts, day in self.timeslot_to_day.items() if day == new_day]
            if available_times:
                new_time = random.choice(available_times)
                individual[course] = (new_time, individual[course][1])

        return individual

    def split_rooms_mutation(self, individual: Dict) -> Dict:
        """Split into more rooms"""
        if not individual or len(individual) == 0:
            return individual

        course = random.choice(list(individual.keys()))
        time, room_assignments = individual[course]

        if len(room_assignments) < len(self.rooms):
            students = [s for room, students in room_assignments for s in students]
            random.shuffle(students)

            new_assignments = []
            remaining_students = students.copy()
            available_rooms = list(set(self.rooms) - {r for r, _ in room_assignments})

            while remaining_students and available_rooms:
                room = random.choice(available_rooms)
                capacity = self.room_capacities[room]
                room_students = remaining_students[:capacity]
                remaining_students = remaining_students[capacity:]
                new_assignments.append((room, room_students))
                available_rooms.remove(room)

            if new_assignments:
                individual[course] = (time, room_assignments + new_assignments)

        return individual

    def mutate(self, individual: Dict) -> Dict:
        """Apply mutation using configured methods."""
        if not individual or len(individual) == 0:
            return individual

        # Randomly select one of the configured mutation methods
        method = random.choice(self.mutation_methods)

        try:
            if method == MutationMethod.TIME_SLOT:
                return self.timeslot_mutation(individual)
            elif method == MutationMethod.ROOM_ASSIGNMENT:
                return self.room_assignment_mutation(individual)
            elif method == MutationMethod.SPLIT_ROOMS:
                return self.split_rooms_mutation(individual)
            elif method == MutationMethod.DAY_CHANGE:
                return self.day_change_mutation(individual)
            else:
                return individual
        except Exception as e:
            print(f"Error during mutation: {str(e)}")
            return individual


    def steady_state_replacement(self, population, offspring, fitness_scores, offspring_fitness):
        replace_count = max(1, int(self.POPULATION_SIZE * 0.1))  
        
        worst_indices = np.argpartition(fitness_scores, -replace_count)[-replace_count:]
        
        best_offspring_indices = np.argpartition(offspring_fitness, replace_count)[:replace_count]
        
        new_population = population.copy()
        for i, idx in enumerate(worst_indices):
            new_population[idx] = offspring[best_offspring_indices[i]]
        return new_population

    def elitism_replacement(self, population, offspring, fitness_scores, offspring_fitness):
        combined_pop = population + offspring
        combined_fitness = fitness_scores + offspring_fitness
        selected_indices = np.argpartition(combined_fitness, self.POPULATION_SIZE)[:self.POPULATION_SIZE]
        return [combined_pop[i] for i in selected_indices], [combined_fitness[i] for i in selected_indices]

    def generational_replacement(self, population, offspring, parent_fitness, offspring_fitness):
        best_parent_idx = np.argmin(parent_fitness)
        return [population[best_parent_idx]] + offspring[:self.POPULATION_SIZE-1], \
              [parent_fitness[best_parent_idx]] + offspring_fitness[:self.POPULATION_SIZE-1]


    def timetable_to_vector(self, timetable: Dict) -> np.ndarray:
        """Convert timetable to a numerical vector for distance calculation"""
        # Create a feature vector representing the timetable
        features = []

        # Feature 1: Timeslot distribution
        timeslot_counts = defaultdict(int)
        for course, (time, _) in timetable.items():
            timeslot_counts[time] += 1
        features.extend([timeslot_counts.get(ts, 0) for ts in sorted(self.timeslot_to_day.keys())])

        # Feature 2: Room usage distribution
        room_usage = defaultdict(int)
        for course, (_, rooms) in timetable.items():
            for room, _ in rooms:
                room_usage[room] += 1
        features.extend([room_usage.get(room, 0) for room in sorted(self.rooms)])

        return np.array(features)

    def calculate_diversity(self, population: List[Dict]) -> float:
        """Calculate population diversity using multiple metrics"""
        if len(population) < 2:
            return 0.0

        # Convert population to feature vectors
        vectors = [self.timetable_to_vector(ind) for ind in population]

        # Calculate pairwise distances
        distances = cdist(vectors, vectors, 'euclidean')

        # Exclude diagonal (distance to self)
        np.fill_diagonal(distances, np.nan)

        # Calculate mean distance
        mean_distance = np.nanmean(distances)

        # Normalize by maximum possible distance
        max_possible = np.sqrt(len(self.timeslot_to_day) + len(self.rooms)) * self.POPULATION_SIZE
        normalized_diversity = mean_distance / max_possible if max_possible > 0 else 0

        return normalized_diversity

    def fitness_sharing(self, population: List[Dict], fitness_scores: List[float]) -> List[float]:
        """Apply fitness sharing to maintain diversity"""
        if len(population) < 2:
            return fitness_scores

        # Convert population to feature vectors
        vectors = [self.timetable_to_vector(ind) for ind in population]
        vectors = np.array(vectors)

        # Calculate pairwise distances
        distances = cdist(vectors, vectors, 'euclidean')

        # Apply sharing function
        shared_fitness = np.zeros(len(population))
        sigma = self.SHARING_RADIUS * np.max(distances)  # Sharing radius

        for i in range(len(population)):
            # Calculate niche count
            within_radius = distances[i] < sigma
            sharing_values = 1 - (distances[i][within_radius] / sigma) ** self.ALPHA
            niche_count = np.sum(sharing_values)
            niche_count = max(niche_count, 1)  # Avoid division by zero



            # Adjust fitness
            shared_fitness[i] = fitness_scores[i] / niche_count

        return shared_fitness.tolist()

    def crowding_replacement(self, parents: List[Dict], offspring: List[Dict],
                             parent_fitness: List[float], offspring_fitness: List[float]) -> Tuple[
        List[Dict], List[float]]:
        """Apply crowding replacement to maintain diversity"""
        combined = parents + offspring
        combined_fitness = parent_fitness + offspring_fitness

        # If we're not at capacity, return all
        if len(combined) <= self.POPULATION_SIZE:
            return combined, combined_fitness

        # Select most diverse subset
        selected_indices = []
        remaining_indices = set(range(len(combined)))

        # First select the best individual
        best_idx = np.argmin(combined_fitness)
        selected_indices.append(best_idx)
        remaining_indices.remove(best_idx)

        # Then select individuals that are most different from already selected ones
        vectors = [self.timetable_to_vector(combined[i]) for i in range(len(combined))]

        while len(selected_indices) < self.POPULATION_SIZE and remaining_indices:
            # Calculate minimum distance to selected individuals for each remaining individual
            min_distances = []
            for i in remaining_indices:
                dists = [np.linalg.norm(vectors[i] - vectors[j]) for j in selected_indices]
                min_distances.append(np.min(dists) if dists else 0)

            # Select the individual with maximum minimum distance
            idx = max(zip(remaining_indices, min_distances), key=lambda x: x[1])[0]
            selected_indices.append(idx)
            remaining_indices.remove(idx)

        # Create new population
        new_pop = [combined[i] for i in selected_indices]
        new_fitness = [combined_fitness[i] for i in selected_indices]

        return new_pop, new_fitness

    def run_evolution(self, num_runs: int = 1, seeds: List[int] = None):
        """Run the genetic algorithm multiple times with different configurations."""
        if seeds is None:
            seeds = [random.randint(0, 100000) for _ in range(num_runs)]

        for run in range(num_runs):
            self.current_run_seed = seeds[run]
            random.seed(self.current_run_seed)
            np.random.seed(self.current_run_seed)

            print(f"\nRun {run + 1}/{num_runs} with seed {self.current_run_seed}")
            print(f"Configuration: Selection={self.selection_method}, Crossover={self.crossover_method}")
            print(f"Mutation methods: { self.mutation_methods}")
            print(f"Survivor selection: {self.survivor_selection_method}")
            print(f"Diversity method: {self.diversity_method}")

            start_time = time.time()

            # Initialize population
            population = []
            for _ in range(self.POPULATION_SIZE):
                ind = self.create_individual()
                if ind:  # Only add valid individuals
                    population.append(ind)

            if not population:
                raise ValueError("Failed to create initial population")

            # Evaluate initial population
            with ThreadPoolExecutor(max_workers=self.NUM_THREADS) as executor:
                results = list(executor.map(self.hybrid_fitness, population))
                fitness_scores = [result[2] for result in results]
                self.penalty_details.extend([result[1] for result in results])

            best_idx = np.argmin(fitness_scores)
            self.best_timetable = population[best_idx]
            self.best_fitness = fitness_scores[best_idx]
            self.fitness_history.append(self.best_fitness)
            self.diversity_history.append(self.calculate_diversity(population))

            # Evolution loop
            stagnation = 0
            for gen in range(self.GENERATIONS):
                new_population = []

                # Elitism - preserve best individuals
                elite_size = max(1, int(self.POPULATION_SIZE * self.ELITISM_RATE))
                elite_indices = np.argpartition(fitness_scores, elite_size)[:elite_size]
                new_population.extend([population[i] for i in elite_indices])

                # Generate offspring
                offspring = []
                while len(offspring) < (self.POPULATION_SIZE - elite_size):
                    # Parent selection
                    if self.selection_method == SelectionMethod.TOURNAMENT:
                        parent1 = self.tournament_selection(population, fitness_scores)
                        parent2 = self.tournament_selection(population, fitness_scores)
                    elif self.selection_method == SelectionMethod.ROULETTE:
                        parent1 = self.roulette_wheel_selection(population, fitness_scores)
                        parent2 = self.roulette_wheel_selection(population, fitness_scores)
                    elif self.selection_method == SelectionMethod.EXPONENTIAL_RANK:
                        parent1 = self.exponential_rank_selection(population, fitness_scores)
                        parent2 = self.exponential_rank_selection(population, fitness_scores)
                    else:
                        parent1 = random.choice(population)
                        parent2 = random.choice(population)

                    # Crossover
                    if random.random() < self.CROSSOVER_RATE:
                        if self.crossover_method == CrossoverMethod.UNIFORM:
                            child1, child2 = self.uniform_crossover(parent1, parent2)
                        elif self.crossover_method == CrossoverMethod.TWO_POINT:
                            child1, child2 = self.two_point_crossover(parent1, parent2)
                        else:
                            child1, child2 = parent1, parent2
                    else:
                        child1, child2 = parent1, parent2

                    # Mutation
                    if random.random() < self.MUTATION_RATE:
                        child1 = self.mutate(child1)
                    if random.random() < self.MUTATION_RATE:
                        child2 = self.mutate(child2)

                    offspring.extend([child1, child2])

                # Evaluate offspring
                with ThreadPoolExecutor(max_workers=self.NUM_THREADS) as executor:
                    offspring_results = list(executor.map(self.hybrid_fitness, offspring))
                    offspring_fitness = [result[2] for result in offspring_results]
                    self.penalty_details.extend([result[1] for result in offspring_results])

                # Apply diversity maintenance
                if self.diversity_method == DiversityMethod.FITNESS_SHARING:
                    # Apply fitness sharing to offspring
                    offspring_fitness = self.fitness_sharing(offspring, offspring_fitness)

                    # Combine populations
                    combined_pop = population + offspring
                    combined_fitness = fitness_scores + offspring_fitness

                    # Select best individuals
                    selected_indices = np.argpartition(combined_fitness, self.POPULATION_SIZE)[:self.POPULATION_SIZE]
                    population = [combined_pop[i] for i in selected_indices]
                    fitness_scores = [combined_fitness[i] for i in selected_indices]

                elif self.diversity_method == DiversityMethod.CROWDING:
                    # Apply crowding replacement
                    population, fitness_scores = self.crowding_replacement(
                        population, offspring, fitness_scores, offspring_fitness
                    )

                elif self.diversity_method == DiversityMethod.HYBRID:
                    # Apply both methods
                    # First apply fitness sharing to offspring
                    shared_offspring_fitness = self.fitness_sharing(offspring, offspring_fitness)

                    # Then apply crowding replacement
                    population, fitness_scores = self.crowding_replacement(
                        population, offspring, fitness_scores, shared_offspring_fitness
                    )

                else:  # No diversity maintenance
                    # Combine and select
                    combined_pop = population + offspring
                    combined_fitness = fitness_scores + offspring_fitness

                if self.survivor_selection_method == SurvivorSelection.ELITISM:
                    population, fitness_scores = self.elitism_replacement(
                        population, offspring, fitness_scores, offspring_fitness
                    )
                elif self.survivor_selection_method == SurvivorSelection.STEADY_STATE:
                    population, fitness_scores = self.steady_state_replacement(
                        population, offspring, fitness_scores, offspring_fitness
                    )
                elif self.survivor_selection_method == SurvivorSelection.GENERATIONAL:
                    population, fitness_scores = self.generational_replacement(
                        population, offspring, fitness_scores, offspring_fitness
                    )

                # Update best solution
                current_best_idx = np.argmin(fitness_scores)
                current_best_fitness = fitness_scores[current_best_idx]

                if current_best_fitness < self.best_fitness:
                    self.best_timetable = population[current_best_idx]
                    self.best_fitness = current_best_fitness
                    stagnation = 0
                else:
                    stagnation += 1

                self.fitness_history.append(self.best_fitness)
                diversity = self.calculate_diversity(population)
                self.diversity_history.append(diversity)

                # Early stopping
                if stagnation >= self.MAX_STAGNATION:
                    print(f"Early stopping at generation {gen}")
                    break

                # Progress reporting
                if gen % 10 == 0:
                    avg_fitness = np.mean(fitness_scores)
                    print(
                        f"Gen {gen:3d} | Best: {self.best_fitness:8.1f} | Avg: {avg_fitness:8.1f} | Diversity: {diversity:.2f}")

            # Record run statistics
            run_time = time.time() - start_time
            self.run_stats.append({
                'run': run + 1,
                'seed': self.current_run_seed,
                'best_fitness': self.best_fitness,
                'generations': gen + 1,
                'time_seconds': run_time,
                'selection_method': self.selection_method,
                'crossover_method': self.crossover_method,
                'mutation_methods': [self.mutation_methods],
                'survivor_selection': self.survivor_selection_method,
                'diversity_method': self.diversity_method,
                'final_diversity': self.diversity_history[-1]
            })

            print(f"\nRun {run + 1} completed in {run_time:.2f} seconds")
            print(f"Best fitness achieved: {self.best_fitness}")
            print(f"Final population diversity: {self.diversity_history[-1]:.2f}")

            # Verify all courses are scheduled in the best solution
            missing_courses = set(self.courses) - set(self.best_timetable.keys())
            if missing_courses:
                print(f"\nWARNING: {len(missing_courses)} courses not scheduled in final solution!")
                print("Missing courses:", missing_courses)
            else:
                print("\nAll courses successfully scheduled in final solution!")

        return self.best_timetable

    def print_timetable(self, timetable: Dict):
        """Print detailed timetable information, conflicts, and usage stats."""
        if not timetable:
            print("No valid timetable to display")
            return

        # Verify all courses are scheduled
        missing_courses = set(self.courses) - set(timetable.keys())
        if missing_courses:
            print(f"\nWARNING: {len(missing_courses)} courses not scheduled!")
            print("Missing courses:", missing_courses)

        # Prepare schedule data
        schedule_data = []
        student_time_map = defaultdict(list)
        room_time_map = defaultdict(list)

        for course, (time, room_assignments) in timetable.items():
            course_name = self.course_names.get(course, 'Unknown')
            day = self.timeslot_to_day.get(time, 'Unknown')

            for room, students in room_assignments:
                capacity = self.room_capacities.get(room, 1)

                # Track students for conflict detection
                for student in students:
                    student_time_map[student].append(time)

                # Track room-time usage
                room_time_map[(room, time)].append(course)

                schedule_data.append({
                    'Day': day,
                    'Time': time,
                    'Room': room,
                    'Course': course_name,
                    'Students': len(students),
                    'Capacity': capacity,
                    'Utilization': len(students) / capacity if capacity > 0 else 0,
                    'Conflict': len(students) > capacity
                })

        # Create DataFrame
        schedule_df = pd.DataFrame(schedule_data)

        # Print summary
        print("\nExam Timetable Summary:")
        print(schedule_df.sort_values(['Day', 'Time', 'Room']).to_string(index=False))

        # Print statistics
        print("\nSchedule Statistics:")
        print(f"Total courses scheduled: {len(timetable)}/{len(self.courses)}")
        print(f"Total exam sessions: {len(schedule_df)}")
        print(f"Total rooms used: {len(set(schedule_df['Room']))}")
        print(f"Total days used: {len(set(schedule_df['Day']))}")
        print(f"Average room utilization: {schedule_df['Utilization'].mean():.2%}")
        print(f"Hard constraint violations: {sum(schedule_df['Conflict'])}")

        # Room usage details
        print("\nRoom Usage Details:")
        room_stats = schedule_df.groupby('Room').agg({
            'Students': 'sum',
            'Capacity': 'sum',
            'Utilization': 'mean',
            'Time': 'count'
        }).rename(columns={'Time': 'UsageCount'})
        print(room_stats.sort_values('Utilization', ascending=False).to_string())

        # Daily distribution
        print("\nDaily Exam Distribution:")
        daily_stats = schedule_df.groupby('Day').agg({
            'Time': 'nunique',
            'Room': 'nunique',
            'Students': 'sum'
        }).rename(columns={
            'Time': 'TimeSlotsUsed',
            'Room': 'RoomsUsed'
        })
        print(daily_stats.sort_index().to_string())

    def plot_results(self):
        import matplotlib.pyplot as plt

        if not self.fitness_history:
            print("No results to plot")
            return None

        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        axes[0].plot(self.fitness_history)
        axes[0].set_title('Fitness Progress Over Generations')
        axes[0].set_xlabel('Generation')
        axes[0].set_ylabel('Fitness Score (Lower is Better)')
        axes[0].grid(True)

        axes[1].plot(self.diversity_history)
        axes[1].set_title('Population Diversity Over Generations')
        axes[1].set_xlabel('Generation')
        axes[1].set_ylabel('Diversity')
        axes[1].grid(True)

        plt.tight_layout()
        return fig

    def print_run_statistics(self):
        """Print statistics from multiple runs."""
        if not self.run_stats:
            print("No run statistics available")
            return

        stats_df = pd.DataFrame(self.run_stats)
        print("\nRun Statistics Summary:")
        print(stats_df.to_string(index=False))
        
    def export_schedule(self, schedule):
        rows = []
        for course_id, (timeslot_id, classroom_id) in schedule.items():
            if isinstance(classroom_id, list):
                # Extract room names from list of tuples (room, students)
                rooms = ", ".join(room for room, _ in classroom_id)
            else:
                rooms = classroom_id

            rows.append({
                "Course ID": course_id,
                "Course Name": self.course_names.get(course_id, ""),
                "Timeslot ID": timeslot_id,
                "Day": self.timeslot_to_day.get(timeslot_id, ""),
                "Classroom": rooms
            })
        return pd.DataFrame(rows)

    def get_timetable_report(self, timetable: Dict) -> str:
        """Capture the print_timetable output as a string."""
        buffer = io.StringIO()
        sys_stdout = sys.stdout
        sys.stdout = buffer
        try:
            self.print_timetable(timetable)
            output = buffer.getvalue()
        finally:
            sys.stdout = sys_stdout
        return output
    def get_plot_figure(self):
        import matplotlib.pyplot as plt
        return plt.gcf()
# Main execution

