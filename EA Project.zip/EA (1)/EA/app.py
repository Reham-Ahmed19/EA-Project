import streamlit as st
import pandas as pd
from main import run_scheduler_with_config
import tracemalloc
tracemalloc.start()
import io

st.set_page_config(page_title="Exam Scheduler", layout="wide")

st.title("Exam Timetabling System")

# 1. File upload section (comes first)
# uploaded_files = st.file_uploader("Upload Required CSV Files",
#                                   type=["csv"],
#                                   accept_multiple_files=True,
#                                   help="Upload schedule, students, courses, classrooms, and timeslots files")

# # Initialize variables
# uploaded_data = {}
# column_mapping = {}
# file_types = {
#     'schedule': None,
#     'students': None,
#     'courses': None,
#     'classrooms': None,
#     'timeslots': None
# }

# 2. File type identification (after upload)
# if uploaded_files:
#     st.success(f"{len(uploaded_files)} file(s) uploaded successfully!")

#     with st.expander("📌 Identify Your Files", expanded=True):
#         st.markdown("**First, identify which file is which:**")

#         uploaded_filenames = [f.name for f in uploaded_files]

#         file_types['schedule'] = st.selectbox(
#             "Select Schedule File (student-course relations)",
#             uploaded_filenames,
#             key='schedule_file'
#         )
#         file_types['students'] = st.selectbox(
#             "Select Students File (student IDs)",
#             uploaded_filenames,
#             key='students_file'
#         )
#         file_types['courses'] = st.selectbox(
#             "Select Courses File (course info)",
#             uploaded_filenames,
#             key='courses_file'
#         )
#         file_types['classrooms'] = st.selectbox(
#             "Select Classrooms File (room capacities)",
#             uploaded_filenames,
#             key='classrooms_file'
#         )
#         file_types['timeslots'] = st.selectbox(
#             "Select Timeslots File (time slots info)",
#             uploaded_filenames,
#             key='timeslots_file'
#         )

#     # 3. Column mapping section
#     tabs = st.tabs([file.name for file in uploaded_files])

#     for idx, uploaded_file in enumerate(uploaded_files):
#         with tabs[idx]:
#             try:
#                 df = pd.read_csv(uploaded_file)
#                 uploaded_data[uploaded_file.name] = df

#                 st.subheader(f"File: {uploaded_file.name}")
#                 st.dataframe(df.head())

#                 # Determine file type and show appropriate column selectors
#                 if uploaded_file.name == file_types['schedule']:
#                     st.markdown("*Select columns for:*")
#                     student_col = st.selectbox("Student ID", df.columns, key=f"student_col_{idx}")
#                     course_col = st.selectbox("Course ID", df.columns, key=f"course_col_{idx}")
#                     column_mapping['schedule'] = {
#                         'student_id': student_col,
#                         'course_id': course_col
#                     }

#                 elif uploaded_file.name == file_types['students']:
#                     st.markdown("*Select student ID column:*")
#                     student_col = st.selectbox("Student ID", df.columns, key=f"students_col_{idx}")
#                     column_mapping['students'] = {'student_id': student_col}

#                 elif uploaded_file.name == file_types['courses']:
#                     st.markdown("*Select columns for:*")
#                     course_col = st.selectbox("Course ID", df.columns, key=f"courses_col_{idx}")
#                     name_col = st.selectbox("Course Name", df.columns, key=f"name_col_{idx}")
#                     column_mapping['courses'] = {
#                         'course_id': course_col,
#                         'course_name': name_col
#                     }

#                 elif uploaded_file.name == file_types['classrooms']:
#                     st.markdown("*Select columns for:*")
#                     room_col = st.selectbox("Classroom ID", df.columns, key=f"room_col_{idx}")
#                     capacity_col = st.selectbox("Capacity", df.columns, key=f"capacity_col_{idx}")
#                     column_mapping['classrooms'] = {
#                         'classroom_id': room_col,
#                         'capacity': capacity_col
#                     }

#                 elif uploaded_file.name == file_types['timeslots']:
#                     st.markdown("*Select columns for:*")
#                     timeslot_col = st.selectbox("Timeslot ID", df.columns, key=f"timeslot_col_{idx}")
#                     day_col = st.selectbox("Day", df.columns, key=f"day_col_{idx}")
#                     column_mapping['timeslots'] = {
#                         'timeslot_id': timeslot_col,
#                         'day': day_col
#                     }

#             except Exception as e:
#                 st.error(f"Error reading {uploaded_file.name}: {e}")

# Sidebar configuration
st.sidebar.header("Algorithm Configuration")

config = {
    "initialization_method": st.sidebar.selectbox("Initialization Method", ["Random", "Heuristic", "Size Based"]),
    "crossover_type": st.sidebar.selectbox("Crossover Type", ["Uniform Crossover", "Single Point Crossover", "Two Point Crossover"]),
    "mutation_type": st.sidebar.selectbox("Mutation Type", ["Time Slot", "Room Assignment", "Split Rooms", "Day Change"]),
    "parent_selection": st.sidebar.selectbox("Parent Selection", ["Tournament Selection", "Roulette Wheel Selection", "Exponential Rank Selection"]),
    "survivor_selection": st.sidebar.selectbox("Survivor Selection", ["Steady State Replacement", "Elitism Replacement", "Generational Replacement"]),
    "population_size": st.sidebar.slider("Population Size", 10, 200, 50),
    "generations": st.sidebar.slider("Number of Generations", 10, 500, 100),
    "mutation_rate": st.sidebar.slider("Mutation Rate", 0.0, 1.0, 0.05),
    "crossover_rate": st.sidebar.slider("Crossover Rate", 0.0, 1.0, 0.8),
    
}
use_tuning = st.sidebar.checkbox("Use Adaptive Parameters")

if st.button("🚀 Run Evolution"):
    with st.spinner("Running scheduling algorithm..."):
        result = run_scheduler_with_config(config,use_tuning)

        if result is None:
            st.error("❌ Failed to generate a valid schedule.")
        else:
            timetable_df, violations, penalties, total_penalty, details, fig, timetable_report = result

            st.success("✅ Schedule generated successfully!")

            st.subheader("📋 Generated Timetable")
            st.dataframe(timetable_df)
            if timetable_df is not None:
                buffer = io.BytesIO()
                with pd.ExcelWriter(buffer, engine='xlsxwriter') as writer:
                    timetable_df.to_excel(writer, index=False, sheet_name='Timetable')
                    writer.close()
                    buffer.seek(0)

                st.download_button(
                    label="📥 Download Timetable as Excel",
                    data=buffer,
                    file_name="exam_timetable.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            st.subheader("📄 Detailed Timetable Report")
            st.text(timetable_report)  # Display the print_timetable output here

            st.subheader("📊 Evolution Plot")
            if fig:
                st.pyplot(fig)

            st.subheader("🚨 Constraint Violations Breakdown")
            st.write("### Raw Violations")
            st.json(violations)

            st.write("### Penalties")
            st.json(penalties)

            st.markdown(f"### 🧮 **Total Penalty:** `{total_penalty}`")

            st.write("### 📌 Details")
            st.json(details)
