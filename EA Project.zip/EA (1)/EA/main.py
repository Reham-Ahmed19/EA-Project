from ea import *

import streamlit as st

def run_scheduler_with_config(config: dict,use_tuning: bool):
    try:
        scheduler = FinalExamScheduler(config=config)

        if use_tuning:
            st.info("🔍 Running parameter tuner...")
            tuner = BasicParameterTuner(scheduler,config=config)
            tuner.simple_tune(num_configs=5, num_runs=2)
            best_params, best_score = tuner.get_best_parameters()

            if best_params:
                st.success(f"✅ Best parameters selected ")
                for param, val in best_params.items():
                    setattr(scheduler, param, val)
            else:
                st.warning("⚠️ No optimal parameters found. Falling back to default.")

        best_schedule = scheduler.run_evolution(num_runs=1)

        if best_schedule:
            timetable_df = scheduler.export_schedule(best_schedule)
            violations, penalties, total_penalty, details = scheduler.check_constraint_violations(best_schedule, verbose=False)

            fig = scheduler.plot_results()
            timetable_report = scheduler.get_timetable_report(best_schedule)  # Get report string here

            return timetable_df, violations, penalties, total_penalty, details, fig, timetable_report

        else:
            print("❌ No valid schedule returned")
            return None

    except Exception as e:
        print(f"Fatal error: {str(e)}")
        return None


